#include "stdlib.h"
#include "stdint.h"
#include "string.h"
#include "stdio.h"
#include <stddef.h>   // <- defines NULL



// condition codes
typedef enum {
    EQ = 0b0000, NE, CS, CC, MI, PL, VS, VC, HI, LS, GE, LT, GT, LE, AL
} condition_code;

typedef struct {
    const char* name;
    condition_code cond;
} CondMap;

CondMap cond_map[] = {
    {"EQ", EQ}, {"NE", NE}, {"CS", CS}, {"CC", CC},
    {"MI", MI}, {"PL", PL}, {"VS", VS}, {"VC", VC},
    {"HI", HI}, {"LS", LS}, {"GE", GE}, {"LT", LT},
    {"GT", GT}, {"LE", LE}, {"AL", AL}
};

condition_code get_condition(const char* name) {
    for (int i = 0; i < sizeof(cond_map) / sizeof(CondMap); i++) {
        if (strcmp(name, cond_map[i].name) == 0) {
            return cond_map[i].cond;
        }
    }
    return -1; // error case
}

// op values
typedef enum {
    data_process = 0b00,
    data_move,
    flow_control,
    system_spec
} op;

// data_processing arithmetic only
typedef enum {
    SUB = 0b0010,
    RSB,
    ADD,
    ADC,
    SBC,
    RSC
} opcode_arithmetc;

// registers
typedef enum {
    R0 = 0b0000, R1, R2, R3, R4, R5, R6, R7,
    R8, R9, R10, R11, R12, R13, R14, R15
} registers;

// instruction type wrapper
typedef struct {
    op type;
    union {
        opcode_arithmetc opcode_dp;
    } opcode;
} Instruction_type;

// full 32-bit instruction representation
typedef struct {
    unsigned int src2 : 12;
    unsigned int rd : 4;
    unsigned int rn : 4;
    unsigned int s : 1;
    unsigned int fn : 4;
    unsigned int hash : 1;
    unsigned int op : 2;
    unsigned int cond : 4;
} instruction;

// register name to enum mapping
typedef struct {
    const char* name;
    registers reg;
} RegMap;

RegMap reg_map[] = {
    {"R0", R0}, {"R1", R1}, {"R2", R2}, {"R3", R3},
    {"R4", R4}, {"R5", R5}, {"R6", R6}, {"R7", R7},
    {"R8", R8}, {"R9", R9}, {"R10", R10}, {"R11", R11},
    {"R12", R12}, {"R13", R13}, {"R14", R14}, {"R15", R15}
};

registers get_register(const char* name) {
    for (int i = 0; i < sizeof(reg_map) / sizeof(RegMap); i++) {
        if (strcmp(name, reg_map[i].name) == 0) {
            return reg_map[i].reg;
        }
    }
    return -1; // error case
}

// Combined mnemonic name to opcode + type
typedef struct {
    const char* name;
    opcode_arithmetc opcode;
    op type;
} OpInfo;

OpInfo op_info[] = {
    {"ADD", ADD, data_process},
    {"SUB", SUB, data_process},
    {"RSB", RSB, data_process},
    {"ADC", ADC, data_process},
    {"SBC", SBC, data_process},
    {"RSC", RSC, data_process}
};

int get_op_info(const char* name, opcode_arithmetc* opcode_out, op* type_out) {
    for (int i = 0; i < sizeof(op_info) / sizeof(OpInfo); i++) {
        if (strcmp(name, op_info[i].name) == 0) {
            *opcode_out = op_info[i].opcode;
            *type_out = op_info[i].type;
            return 1;
        }
    }
    return 0;
}

int main() {
     const char* beginning = "_Start:";
     FILE* out = fopen("output.bin", "wb"); // append mode
    FILE* fptr = fopen("assembly.asm", "r");

    if (fptr !=NULL ) {
       
        char line[100];
        int found = 0;

        while (fgets(line, sizeof(line), fptr)) {
            if (strstr(line, beginning)) {
                found = 1;
                break;
            }
        }

        if (found) {
            while (fgets(line, sizeof(line), fptr)) {
                char* token = strtok(line, " ,\n");
                if (!token) continue;

                if (token[strlen(token) - 1] == ':') {
                    token = strtok(NULL, " ,\n");
                }

                char* mnemonic = token;

                // Detect and parse condition
                int len = strlen(mnemonic);
                condition_code cond = AL; // Default to AL
                char suffix[3] = {0};

                if (len >= 4) {
                    strncpy(suffix, &mnemonic[len - 2], 2);
                    suffix[2] = '\0';
                    condition_code parsed = get_condition(suffix);
                    if (parsed != -1) {
                        cond = parsed;
                        mnemonic[len - 2] = '\0'; // Trim condition suffix
                    }
                }

                char* rdvalue = strtok(NULL, " ,\n");
                char* rnvalue = strtok(NULL, " ,\n");
                char* operand2 = strtok(NULL, " ,\n");
                                instruction inst = {0};
                inst.cond = cond;

                Instruction_type instr_type;
                
                if (!rdvalue || !rnvalue || !operand2) {
                    printf("Missing operands: rd=%s, rn=%s, src2=%s\n",
                        rdvalue ? rdvalue : "NULL",
                        rnvalue ? rnvalue : "NULL",
                        operand2 ? operand2 : "NULL");
                    continue;
                }



                if (get_op_info(mnemonic, &instr_type.opcode.opcode_dp, &instr_type.type)) {
                    inst.fn = instr_type.opcode.opcode_dp;
                    inst.op = instr_type.type;
                } else {
                    printf("Unknown mnemonic: %s\n", mnemonic);
                    continue;
                }

                if (operand2[0] == '#') {
                    inst.hash = 1;
                    inst.src2 = atoi(operand2 + 1); // Skip '#'
                } else {
                    inst.hash = 0;
                    //printf("get_register(operand2) = %d\n", get_register(operand2));

                    inst.src2 = get_register(operand2);

                                    int src_val = get_register(operand2);
                                    if (src_val == -1) {
                                        printf("Invalid src2 register: %s\n", operand2);
                                        continue;
                                    }
                                    inst.src2 = src_val;


                }

                inst.rd = get_register(rdvalue);
                inst.rn = get_register(rnvalue);

                if((get_register(rnvalue)==-1)||(get_register(rdvalue)==-1))
                {
                    printf("Error: Wrong Register Value\n");
                    continue;

                }
                //error handling r15 in rn with add and sub

                else if ((instr_type.opcode.opcode_dp == ADD || instr_type.opcode.opcode_dp == SUB) && inst.rn == R15) 
                {
                    //printf("get_register(rn) = %d\n", get_register(rnvalue));
                    printf("Error: R15 cannot be used as rn in ADD or SUB\n");

                    continue;
                }

                //error handling #imm range
                if (inst.hash==1 && inst.src2 > 0xFFF) 
                {
                    printf("Immediate value out of range: %u\n", inst.src2);
                    continue;
                }



                // Optional: Debug print
                printf("Instruction: op=%u, fn=%u, cond=%u, rd=%u, rn=%u, src2=%u, hash=%u\n",
                       inst.op, inst.fn, inst.cond, inst.rd, inst.rn, inst.src2, inst.hash);

                
                if (out) {
                    fwrite(&inst, sizeof(inst), 1, out);
                 
                } else {
                    printf("Error opening output file.\n");
                }
       
            }
        } 
        else 
        {

            printf("_Start: label not found.\n");
        }

        fclose(fptr);
        fclose(out);
    } 
    else 
    {
        printf("Can't access file.\n");
    }

    return 0;
}
