/*
 * main.c
 *
 *  Created on: Jul 24, 2025
 *      Author: Catherine Nader
 */


#include "STD_TYPES.h"

#include "BIT_MATH.h"
#include "MRCC_Interface.h"
#include "MGPIO_Interface.h"
#include "MNVIC_Interface.h"
#include "MINT_Interface.h"
#include "MSTK_Interface.h"
#include "HSevenSegment_Interface.h"
#include "HUART_Interface.h"

u8 uart_value=11;
int i=0;
#include "abba.h"
volatile int paused = 1;
int bin_audio;
volatile int music_playing = 0;
int music_index = 0;
int counter_running = 0;
#define abba_raw_len 16006
u8 last_uart_value = 255;


int main()
{

//buzzer and led in porta
	//portb seven segment
	//a9 and a10 rx and tx
	//dac portc 8 pins

	//clock init

	MRCC_voidInit();
	MRCC_voidEnablePeripheralClock(AHB1_BUS,AHB1_GPIOA);
	MRCC_voidEnablePeripheralClock(APB2_BUS,APB2_USART1);
	MRCC_voidEnablePeripheralClock(AHB1_BUS,AHB1_GPIOB);



	//systick

	MSTK_voidInit();

    //UART INIT


	HUART_voidInit(UART1);
	MGPIO_voidSetMode(PORTA,PIN9,Alternative_Func);
	MGPIO_voidSetAlternativeConfig(PORTA,PIN9,AF7);

	MGPIO_voidSetMode(PORTA,PIN10,Alternative_Func);
	MGPIO_voidSetAlternativeConfig(PORTA,PIN10,AF7);

	//LED
	MGPIO_voidSetMode(PORTA,PIN0,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN0,Push_Pull,Low_Speed);

	//BUZZER
	MGPIO_voidSetMode(PORTA,PIN1,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN1,Push_Pull,Low_Speed);

	//Seven Segment

	HSevenSegment_voidInit(PORTB);

	//DAC Pins
	MGPIO_voidSetMode(PORTB,PIN7,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN7,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN8,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN8,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN9,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN9,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN10,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN10,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN12,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN12,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN13,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN13,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN14,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN14,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTB,PIN15,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTB,PIN15,Push_Pull,Low_Speed);

	u8 pins[] = {PIN7, PIN8, PIN9, PIN10,PIN12, PIN13, PIN14,PIN15};


		while (1)
		{
		    uart_value = HUART_u8Read(UART1);
if(uart_value!=last_uart_value)
{
		    last_uart_value = uart_value;

		    switch (uart_value)
		    {
		        case 0:
		            MGPIO_voidSetPinValue(PORTA, PIN0, HIGH);
		            break;

		        case 1:
		            MGPIO_voidSetPinValue(PORTA, PIN0, LOW);
		            break;

		        case 2:
		            music_playing = 1;
		            music_index = 0;
		            break;

		        case 3:
		            music_playing = 0;
		            music_index = 0;
		            for (int j = 0; j < 8; j++) {
		                MGPIO_voidSetPinValue(PORTB, pins[j], LOW);
		            }
		            break;

		        case 4:
		            counter_running = 1;
		            i = 0;
		            break;

		        case 5:
		            counter_running = 0;

			        HSevenSegment_voidNumber(0, PORTB);
		            break;

		        case 6:
		            MGPIO_voidSetPinValue(PORTA, PIN1, HIGH);
		            break;

		        case 7:
		            MGPIO_voidSetPinValue(PORTA, PIN1, LOW);
		            break;

		        case 8:
		            MGPIO_voidSetPinValue(PORTA, PIN0, LOW);
		            MGPIO_voidSetPinValue(PORTA, PIN1, LOW);
		            counter_running = 0;
		            music_playing = 0;
		            music_index = 0;
		            for (int j = 0; j < 8; j++) {
		                MGPIO_voidSetPinValue(PORTB, pins[j], LOW);
		            }
		            break;

		        case 9:
		            MGPIO_voidSetPinValue(PORTA, PIN0, HIGH);
		            MSTK_voidDelayms(1000);
		            MGPIO_voidSetPinValue(PORTA, PIN0, LOW);
		            MSTK_voidDelayms(1000);
		            break;

		        default:
		            break;
		    }
}

		    // ---------- This runs independently of UART commands ----------

		    if (music_playing && music_index < abba_raw_len) {
		        bin_audio = abba_raw[music_index++];
		        for (int j = 0; j < 8; j++) {
		            u8 bit = (bin_audio >> j) & 0x01;
		            MGPIO_voidSetPinValue(PORTB, pins[j], bit ? HIGH : LOW);
		        }
		        MSTK_voidDelayus(125);
		    }

		    if (counter_running) {
		    	for(int i;i<10;i++)
		    	{
		        HSevenSegment_voidNumber(i, PORTB);
		        MSTK_voidDelayms(2000);
		       } // Slow enough to see


		    }
		}






return 0;
}


