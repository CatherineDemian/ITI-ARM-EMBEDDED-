/*
 * MINT_Program.c
 *
 *  Created on: Jul 15, 2025
 *      Author: Catherine Nader
 */

#include <MINT_Interface.h>
#include "STD_TYPES.h"


//static void(*GlobalPTR_PtrEXTI0)(void)= NULL;
static void(*GlobalPTR_PtrEXTI[16])(void) = {NULL};

void void_SetInterrupt(EXTILINE_t copyuddtLine,EXTI_PORT_t copyuddtPort)
{

SYSCFG->EXTICR[copyuddtLine/SYSDIV]&= ~(SYSMask<<(copyuddtLine%SYSDIV)*4);
SYSCFG->EXTICR[copyuddtLine/SYSDIV] |= (copyuddtPort<<(copyuddtLine%SYSDIV)*4);
}

void MEXTI_voidEnable(EXTILINE_t copyuddtLine)
{
	EXTI->IMR |=(1<<copyuddtLine);
}

void MEXTI_voidDisable(EXTILINE_t copyuddtLine)
{
	EXTI->IMR &= ~(1<<copyuddtLine);
}

void MEXTI_voidSetTrigger(EXTILINE_t copyuddtLine,EXTI_Trigger_t copyuddtTrigger)
{
switch(copyuddtTrigger)
{
case EXTI_Falling:

	EXTI->RTSR &= ~(1<<copyuddtLine);
	EXTI->FTSR |= (1<<copyuddtLine);
	break;
case EXTI_Rising:
	EXTI->	FTSR &= ~(1<<copyuddtLine);
	EXTI->RTSR |= (1<<copyuddtLine);
	break;

case EXTI_NoChange:

	EXTI->RTSR |= (1<<copyuddtLine);
	EXTI->FTSR |= (1<<copyuddtLine);
	break;
default:
	break;
}

}
/*
void EXTI_voidCallBack(void(*ptr)(void))
{

	GlobalPTR_PtrEXTI0=ptr;
}

void EXTI0_IRQHandler()
{

if(GlobalPTR_PtrEXTI0!=NULL)
{
	GlobalPTR_PtrEXTI0();
	EXTI->PR|=(1<<0); //clear pending reg by setting 1
}

}

*/
void EXTI_voidCallBack(u8 line, void(*ptr)(void))
{
    if (line < 16)
    {
        GlobalPTR_PtrEXTI[line] = ptr;
    }
}

// Interrupt Handlers
void EXTI0_IRQHandler(void)
{
    if (GlobalPTR_PtrEXTI[0]) GlobalPTR_PtrEXTI[0]();
    EXTI->PR |= (1 << 0);
}

void EXTI1_IRQHandler(void)
{
    if (GlobalPTR_PtrEXTI[1]) GlobalPTR_PtrEXTI[1]();
    EXTI->PR |= (1 << 1);
}

void EXTI2_IRQHandler(void)
{
    if (GlobalPTR_PtrEXTI[2]) GlobalPTR_PtrEXTI[2]();
    EXTI->PR |= (1 << 2);
}

void EXTI3_IRQHandler(void)
{
    if (GlobalPTR_PtrEXTI[3]) GlobalPTR_PtrEXTI[3]();
    EXTI->PR |= (1 << 3);
}

void EXTI4_IRQHandler(void)
{
    if (GlobalPTR_PtrEXTI[4]) GlobalPTR_PtrEXTI[4]();
    EXTI->PR |= (1 << 4);
}

void EXTI9_5_IRQHandler(void)
{
    for (u8 i = 5; i <= 9; i++)
    {
        if (EXTI->PR & (1 << i))
        {
            if (GlobalPTR_PtrEXTI[i]) GlobalPTR_PtrEXTI[i]();
            EXTI->PR |= (1 << i);
        }
    }
}

void EXTI15_10_IRQHandler(void)
{
    for (u8 i = 10; i <= 15; i++)
    {
        if (EXTI->PR & (1 << i))
        {
            if (GlobalPTR_PtrEXTI[i]) GlobalPTR_PtrEXTI[i]();
            EXTI->PR |= (1 << i);
        }
    }
}
