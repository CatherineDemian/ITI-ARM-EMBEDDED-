

#ifndef MSTK_CONFIG_H
#define MSTK_CONFIG_H

/*Choose Between
1-STK_AHB  
2-STK_AHB_8*/
#define STK_SYSTEM_CLK   STK_AHB_8


 
#endif
