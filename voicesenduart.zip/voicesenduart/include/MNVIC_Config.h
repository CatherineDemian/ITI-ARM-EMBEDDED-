
#ifndef MNVIC_CONFIG_H
#define MNVIC_CONFIG_H

#define Split_Bits group_3_1

#endif
