/*
 * main.c
 *
 *  Created on: Jul 24, 2025
 *      Author: Catherine Nader
 */


#include "STD_TYPES.h"

#include "BIT_MATH.h"
#include "MRCC_Interface.h"
#include "MGPIO_Interface.h"
#include "MNVIC_Interface.h"
#include "MINT_Interface.h"
#include "MSTK_Interface.h"
#include "HSevenSegment_Interface.h"
#include "HUART_Interface.h"

//SONGS

#include "samppp1.h"
#include "abba.h"
#include "samp.h"

typedef struct {
	unsigned int length;
	unsigned char *data;
} Songs_t;

int bin_audio;
volatile int paused = 1;
int songlist_index = 0;
volatile int play_request = 0;


#define babaaa_raw_len 15992
#define samp_raw_len 8049
#define abba_raw_len 16006

Songs_t songsList[] = {
		{abba_raw_len, abba_raw},
		{babaaa_raw_len, babaaa_raw},
		{samp_raw_len, samp_raw}
};

#define TotalSongs (sizeof(songsList)/sizeof(songsList[0]))


void audio_extract(unsigned char audio_bytes[],unsigned int length)
{

	for(int i=0;i<length;i++)
	{

		  while (paused) { };
		bin_audio=audio_bytes[i];


			for (int j = 0; j < 8; j++)
			{
				u8 bit = (bin_audio >> j) & 0x01;
				MGPIO_voidSetPinValue(PORTA, 1 << j, bit ? HIGH : LOW);

			}

			MSTK_voidDelayus(125);


	}

}




void Button0_Handler(void)
{

        songlist_index = (songlist_index + 1) % TotalSongs;
        play_request = 1;

}
void Button1_Handler(void)
{
	 paused ^= 1;

	}
void Button2_Handler(void)
{
	   songlist_index = (songlist_index + TotalSongs - 1) % TotalSongs;
	    play_request = 1;

}




int main()
{

	MRCC_voidInit();
	MRCC_voidEnablePeripheralClock(AHB1_BUS,AHB1_GPIOA);
	MRCC_voidEnablePeripheralClock(AHB1_BUS,AHB1_GPIOB);
	MRCC_voidEnablePeripheralClock(APB2_BUS,APB2_SYSCFG);


	//PINS DAC

		MGPIO_voidSetOutputConfig(PORTA,PIN0,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN0,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN0,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN1,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN1,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN2,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN2,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN3,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN3,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN4,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN4,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN5,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN5,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN6,OUTPUT);
	MGPIO_voidSetOutputConfig(PORTA,PIN6,Push_Pull,Low_Speed);
	MGPIO_voidSetMode(PORTA,PIN7,OUTPUT);
		MGPIO_voidSetOutputConfig(PORTA,PIN7,Push_Pull,Low_Speed);

		//3 buttons Input

		MGPIO_voidSetMode(PORTB,PIN0,INPUT);
		MGPIO_voidSetMode(PORTB,PIN1,INPUT);
		MGPIO_voidSetMode(PORTB,PIN2,INPUT);

		MGPIO_voidSetInputConfig(PORTB,PIN0,PULLDOWN);
		MGPIO_voidSetInputConfig(PORTB,PIN1,PULLDOWN);
		MGPIO_voidSetInputConfig(PORTB,PIN2,PULLDOWN);

		//ENABLE SYSTICK
		MSTK_voidInit();

//BUTTON INTERRUPT CONFIG
		void_SetInterrupt(EXTI_LINE0,EXTI_PORT_B);
		void_SetInterrupt(EXTI_LINE1,EXTI_PORT_B);
		void_SetInterrupt(EXTI_LINE2,EXTI_PORT_B);

		MEXTI_voidSetTrigger(EXTI_LINE0,EXTI_Rising);
		MEXTI_voidSetTrigger(EXTI_LINE1,EXTI_Rising);
		MEXTI_voidSetTrigger(EXTI_LINE2,EXTI_Rising);

		MEXTI_voidEnable(EXTI_LINE0);
				MEXTI_voidEnable(EXTI_LINE1);
				MEXTI_voidEnable(EXTI_LINE2);

			    EXTI_voidCallBack(EXTI_LINE0, Button0_Handler);
			    EXTI_voidCallBack(EXTI_LINE1, Button1_Handler);
			    EXTI_voidCallBack(EXTI_LINE2, Button2_Handler);

			    MNVIC_voidEnable(6); // EXTI0_IRQn
			    MNVIC_voidEnable(7); // EXTI1_IRQn
			    MNVIC_voidEnable(8); // EXTI2_IRQn
			    __asm volatile ("cpsie i");


while(1)
{


	if (play_request) {
	        play_request = 0;
	 audio_extract(songsList[songlist_index].data, songsList[songlist_index].length);
	}
}





return 0;
}



