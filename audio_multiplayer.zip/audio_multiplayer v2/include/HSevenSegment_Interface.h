
void HSevenSegment_voidInit(u8 port_no);
void HSevenSegment_voidNumber(u8 u8_number,u8 port_no);
