/*
 * uart_Interface.h
 *
 *  Created on: Jul 23, 2025
 *      Author: Catherine Nader
 */

#ifndef HUART_INTERFACE_H_
#define HUART_INTERFACE_H_

#include "STD_TYPES.H"
#include "BIT_MATH.h"
#include "HUART_config.h"
#include "HUART_Private.h"


void HUART_voidInit(UART_t Copy_uddtUART);
void HUART_voidWrite(UART_t Copy_uddtUART,u8 u8data);
u8 HUART_u8Read(UART_t Copy_uddtUART);
void HUART_voidSendString(UART_t Copy_uddtUART, const char* string);



#endif /* HUART_INTERFACE_H_ */
